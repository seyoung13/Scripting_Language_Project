from distutils.core import setup

setup(name='telegram_bot',
      version='1.0',
      py_modules=['telegram_bot'])
